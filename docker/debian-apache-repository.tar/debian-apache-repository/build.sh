docker build -t hackinglab/debian-apache-repository -f Dockerfile .
